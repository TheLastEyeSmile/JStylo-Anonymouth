import java.io.File;
import java.util.List;

import com.memetix.mst.language.Language;
import com.memetix.mst.translate.Translate;


/**
 * @author sadiaafroz
 *
 */
public class Translation {

	public String getTranslation(String original, Language other)
	{
		Translate.setClientId("drexel1"/* Enter your Windows Azure Client Id here */);
	    Translate.setClientSecret("+L2MqaOGTDs4NpMTZyJ5IdBWD6CLFi9iV51NJTXLiYE="/* Enter your Windows Azure Client Secret here */);

	    try {
			String translatedText = Translate.execute(original, Language.ENGLISH,other);
			String backToenglish = Translate.execute(translatedText,other,Language.ENGLISH);
			
			return backToenglish;
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    return null;
	    

	}
	
    public static void main(String[] args) throws Exception {
	    // Set your Windows Azure Marketplace client info - See http://msdn.microsoft.com/en-us/library/hh454950.aspx
	    Translation t = new Translation();
	    Language allOthers[] = {Language.ARABIC, Language.BULGARIAN, Language.CATALAN,
	    		Language.CHINESE_SIMPLIFIED, Language.CHINESE_TRADITIONAL,Language.CZECH,
	    		Language.DANISH,Language.DUTCH,Language.ESTONIAN,Language.FINNISH,
	    		Language.FRENCH,Language.GERMAN,Language.GREEK,Language.HAITIAN_CREOLE,
	    		Language.HEBREW,Language.HINDI,Language.HMONG_DAW,Language.HUNGARIAN,
	    		Language.INDONESIAN,Language.ITALIAN,Language.JAPANESE,
	    		Language.KOREAN,Language.LATVIAN,Language.LITHUANIAN,
	    		Language.NORWEGIAN,Language.POLISH,Language.PORTUGUESE,
	    		Language.ROMANIAN,Language.RUSSIAN,Language.SLOVAK,
	    		Language.SLOVENIAN,Language.SPANISH, Language.SWEDISH, 
	    		Language.THAI, Language.TURKISH, Language.UKRAINIAN, Language.VIETNAMESE};

	    //read file
	    File original = new File("original_data/a_01.txt");
	    String output = "translated/"+original.getName();
	    
	    List<String> allLines = Util.readFile(original, true);
	    
	    String twoWayTranslation = "";
	    int lineNumber = 0;
	    
	    for(String aLine:allLines){
	    	    if(aLine.length()==0) continue;
	    	    twoWayTranslation = "Original: "+aLine+"\n";
	    	    for(Language other:allOthers)
			    {
		 	    	twoWayTranslation+=other.name()+":  "+t.getTranslation(aLine, other)+"\n";
			    }
	    	    Util.writeFile(twoWayTranslation, output+lineNumber, false);
	    	    
	    	    lineNumber++;
		 	    
	    }
	   // System.out.println(translatedText);
	  }

}

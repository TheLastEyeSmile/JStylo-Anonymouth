


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;


public class Util {
 
	public static void writeFile(List<String> allLines,String fileName, boolean append)
	{
		File aFile = new File(fileName);
		FileWriter aFileWriter;
		try {
		 	    if(aFile.exists() == false)
		 	    		aFile.createNewFile();
				
				aFileWriter = new FileWriter(aFile, append); // Open in Append mode
				
				for(String aLine:allLines)
				{
					aFileWriter.write(aLine);
					aFileWriter.write("\n");
					//System.out.println("write in sensor");
					
				}
				aFileWriter.close();
			 	   
				System.out.println("Writing done");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 	   
	}
	public static void creatArffFile(String input, String output, String classname)
	{
		 List<String> allLines= readFile(new File(input), true);
	        //System.out.println();
	     String[] allFeatures = allLines.get(0).split(",");
	     
	     List<String> outputLines = new ArrayList<String>();
	     String relation = "@relation damascus_obfuscation_mod_2\n\n";
	     //@ATTRIBUTE uniqueWords  NUMERIC
	    	 outputLines.add(relation);
	     for(int i=0;i< allFeatures.length-1;i++)
	     {
	    	 String aLine = "@ATTRIBUTE \""+allFeatures[i]+"\" NUMERIC";
	    	 if(outputLines.contains(aLine))
	    		 aLine = "@ATTRIBUTE \""+allFeatures[i]+i+"\" NUMERIC";
	    	 outputLines.add(aLine);
	     }
	     outputLines.add(classname);
	     outputLines.add("@DATA");
	     
	      for(int i=1;i<allLines.size();i++)
	      {
	    	  outputLines.add(allLines.get(i));
	      }
	     writeFile(outputLines, output, false);
	}
	public static void writeFile(String allLines,String fileName, boolean append)
	{
		File aFile = new File(fileName);
		FileWriter aFileWriter;
		try {
		 	    if(aFile.exists() == false)
		 	    		aFile.createNewFile();
				
				aFileWriter = new FileWriter(aFile, append); // Open in Append mode
				
				//for(String aLine:allLines)
				{
					aFileWriter.write(allLines);
					aFileWriter.write("\n");
					//System.out.println("write in sensor");
					
				}
				aFileWriter.close();
			 	   
				System.out.println("Writing done");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
 	   
	}
//	public static void main(String[] args)
//	{
//		//read file
//		String filename = "jezebel_comments/comments.csv";
//		String commentDir = "jezebel_comments/allComments";
//		
//		String encoding = "UTF-8";
//		File commentFile = new File(filename);
//		try {
//			List<String> allLines = FileLineReader.readLines(commentFile, encoding);
//			
//			for(String aLine: allLines)
//			{
//				String[] commentNumberType = aLine.split(",");
//				try{
//					int commentNumber = Integer.parseInt(commentNumberType[0]);
//					
//					
//					String commentType = commentNumberType[1];
//					
//					File comment = new File(commentDir+"/"+commentNumber+".txt");
//					
//					File commentTypeDir = new File(commentType);
//					
//					if(!commentTypeDir.exists())
//						commentTypeDir.mkdir();
//					
//					if(comment.exists())
//					{
//						//move it to comment type directory
//						comment.renameTo(new File(commentTypeDir.getAbsoluteFile()+"/"+commentNumber+".txt"));
//					}
//				}catch(NumberFormatException ne)
//				{
//					continue;
//				}
//				
//				
//			}
//		} catch (UnsupportedEncodingException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	public static List<String> readFile(File file, boolean readAll)
    {
    	List<String> allWords = new ArrayList<String>();
    		
        FileReader aFileReader;
		
		BufferedReader reader = null;
	    
		//File file = new File(txtFile);
 	    if(file.exists() == true)
			try {
				
				
				aFileReader = new FileReader(file); 
				reader = new BufferedReader(aFileReader);
				
				String dataLine = reader.readLine();
				
				while(dataLine!=null)
				{
					if(readAll)
						allWords.add(dataLine);
					else{
						if(!allWords.contains(dataLine))
						{
							
							allWords.add(dataLine);
						}
					}
					
					dataLine = reader.readLine();
					//System.out.println(allFunctionWords.size());
				}
				
				aFileReader.close();
			}catch(IOException e)
			{
				e.printStackTrace();
			}
			
			return allWords;
    	
    }
	public static void fileProcessing(String input, String output)
	{
		
		List<String> allLinesRead = readFile(new File(input), true);
		List<String> allLinesWrite = new ArrayList<String>();
		
		//add captions
		allLinesWrite.add(allLinesRead.get(0));
		
		String writeLine = "";
		for(int i=1; i<allLinesRead.size(); i++ )
		{
			String[] all = allLinesRead.get(i).split(",");
			
			//get the filename
			String file = all[0];
			System.out.println(file);
			writeLine = file.substring(file.lastIndexOf("/")+1, file.lastIndexOf("."));
			for(int j=1; j<all.length; j++)
				writeLine+=","+all[j];
			
			allLinesWrite.add(writeLine);
		}
		Util.writeFile(allLinesWrite, output, false);
		
	}
	
	
	public static void main(String[] args)
	{
		fileProcessing("oct_30/comments_oct_30.csv", "oct_30/comments_oct_30_processed.csv");
		
	}
}
